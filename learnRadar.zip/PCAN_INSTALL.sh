major_ver=8
minor_ver=14
patch_ver=0
wget https://www.peak-system.com/fileadmin/media/linux/files/peak-linux-driver-$major_ver.$minor_ver.$patch_ver.tar.gz

wget https://www.peak-system.com/quick/BasicLinux

tar -xvzf peak-linux-driver-8.14.0.tar.gz
tar -xvzf BasicLinux

sudo apt install -y libpopt-dev

cd peak-linux-driver-$major_ver.$minor_ver.$patch_ver
make clean all
make netdev
sudo make install

cd $(find . -type d -name "libpcanbasic" | grep PCAN-Basic_Linux)/pcanbasic
make clean
make
sudo make install